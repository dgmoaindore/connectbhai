// ConnectBhai backend: WhatsApp OTP, lead saving, and login / register (Netlify Function, Node 18+)
//
// Environment variables (Netlify > Site configuration > Environment variables):
//   WA_TOKEN                 Permanent access token from Meta WhatsApp Cloud API
//   WA_PHONE_ID              Phone number ID of the WhatsApp Business number that sends OTPs
//   WA_TEMPLATE              Approved "Authentication" template name, e.g. connectbhai_otp
//   WA_LANG                  Template language code (default: en)
//   OTP_SECRET               Any long random text, kept secret
//   SHEET_WEBHOOK            Web app URL of google-apps-script.js (lead saving)
//   FIREBASE_SERVICE_ACCOUNT Whole JSON of a Firebase service-account key (login / register)
//   FIREBASE_API_KEY         The apiKey from your Firebase web config
//   OWNER_WHATSAPP           Optional: 919479935365, gets a WhatsApp alert for each lead
//   WA_ALERT_TEMPLATE        Optional: approved "Utility" template for that alert (4 variables)

const crypto = require("crypto");
const TTL = 5 * 60 * 1000; // OTP valid for 5 minutes
const SYNTH = (m) => `m${m}@user.connectbhai.com`; // login email for accounts without a real email

const reply = (status, body) => ({
  statusCode: status,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(body),
});
const isMob = (m) => /^[6-9]\d{9}$/.test(m);
const isEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e);

let _admin;
function admin() {
  if (!_admin) {
    _admin = require("firebase-admin");
    if (!_admin.apps.length)
      _admin.initializeApp({ credential: _admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)) });
  }
  return _admin;
}

const sign = (mobile, otp, exp) =>
  crypto.createHmac("sha256", process.env.OTP_SECRET).update(`${mobile}|${otp}|${exp}`).digest("hex");

function checkOtp(mobile, otp, token) {
  const [exp, sig] = String(token || "").split(".");
  if (!exp || !sig) return "bad_otp";
  if (Date.now() > Number(exp)) return "expired";
  const good = sign(mobile, String(otp || ""), exp);
  if (good.length !== sig.length || !crypto.timingSafeEqual(Buffer.from(good), Buffer.from(sig))) return "bad_otp";
  return null;
}

async function sendTemplate(to, template, params, withCopyButton) {
  const components = [{ type: "body", parameters: params.map((t) => ({ type: "text", text: t })) }];
  if (withCopyButton)
    components.push({ type: "button", sub_type: "url", index: "0", parameters: [{ type: "text", text: params[0] }] });
  const r = await fetch(`https://graph.facebook.com/v21.0/${process.env.WA_PHONE_ID}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.WA_TOKEN}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to,
      type: "template",
      template: { name: template, language: { code: process.env.WA_LANG || "en" }, components },
    }),
  });
  if (!r.ok) throw new Error("WhatsApp send failed: " + (await r.text()));
}

function requestId() {
  const d = new Date(Date.now() + 5.5 * 3600 * 1000); // IST date
  return `CB${d.toISOString().slice(2, 10).replace(/-/g, "")}-${Math.floor(1000 + Math.random() * 9000)}`;
}

async function userByPhone(m) {
  try { return await admin().auth().getUserByPhoneNumber("+91" + m); }
  catch (e) { if (e.code === "auth/user-not-found") return null; throw e; }
}
const tokenFor = async (uid) => ({ customToken: await admin().auth().createCustomToken(uid) });

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return reply(405, { error: "method" });
  let b;
  try { b = JSON.parse(event.body || "{}"); } catch { return reply(400, { error: "bad_json" }); }
  const mobile = String(b.mobile || "").replace(/\D/g, "");
  const needMobile = ["send", "verify", "otpLogin", "register", "resetPw"].includes(b.action);
  if (needMobile && !isMob(mobile)) return reply(400, { error: "bad_mobile" });
  const needOtp = ["verify", "otpLogin", "register", "resetPw"].includes(b.action);
  if (needOtp) {
    const bad = checkOtp(mobile, b.otp, b.token);
    if (bad) return reply(400, { error: bad });
  }

  try {
    switch (b.action) {
      case "send": {
        const otp = String(crypto.randomInt(100000, 1000000));
        const exp = Date.now() + TTL;
        await sendTemplate("91" + mobile, process.env.WA_TEMPLATE, [otp], true);
        return reply(200, { token: `${exp}.${sign(mobile, otp, exp)}` });
      }

      case "verify": { // booking form lead
        const l = b.lead || {};
        const id = requestId();
        const row = {
          requestId: id,
          time: new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }),
          name: String(l.name || "").slice(0, 80),
          mobile,
          area: String(l.area || "").slice(0, 120),
          pincode: String(l.pincode || "").slice(0, 6),
          service: String(l.service || "").slice(0, 60),
          type: String(l.type || "").slice(0, 20),
          status: "New",
        };
        await fetch(process.env.SHEET_WEBHOOK, {
          method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(row),
        });
        if (process.env.OWNER_WHATSAPP && process.env.WA_ALERT_TEMPLATE) {
          sendTemplate(process.env.OWNER_WHATSAPP, process.env.WA_ALERT_TEMPLATE,
            [row.name || "-", mobile, row.area || row.pincode || "-", row.service || "-"], false).catch(() => {});
        }
        return reply(200, { requestId: id });
      }

      case "otpLogin": { // log in with WhatsApp OTP, creating the account on first use
        let u = await userByPhone(mobile);
        const isNew = !u;
        if (!u) u = await admin().auth().createUser({ phoneNumber: "+91" + mobile });
        return reply(200, { ...(await tokenFor(u.uid)), isNew });
      }

      case "register": {
        const name = String(b.name || "").trim().slice(0, 80);
        const email = String(b.email || "").trim().toLowerCase();
        const password = String(b.password || "");
        if (name.length < 2) return reply(400, { error: "bad_name" });
        if (email && !isEmail(email)) return reply(400, { error: "bad_email" });
        if (password.length < 8) return reply(400, { error: "weak_pw" });
        try {
          const u = await admin().auth().createUser({
            displayName: name, phoneNumber: "+91" + mobile, email: email || SYNTH(mobile), password,
          });
          return reply(200, await tokenFor(u.uid));
        } catch (e) {
          if (e.code === "auth/phone-number-already-exists") return reply(400, { error: "mobile_exists" });
          if (e.code === "auth/email-already-exists") return reply(400, { error: "email_exists" });
          throw e;
        }
      }

      case "pwLogin": { // email or mobile + password
        const id = String(b.id || "").trim().toLowerCase();
        let email = id;
        if (!isEmail(id)) {
          const m = id.replace(/\D/g, "").slice(-10);
          const u = isMob(m) ? await userByPhone(m) : null;
          if (!u || !u.email) return reply(400, { error: "bad_login" });
          email = u.email;
        }
        const r = await fetch(
          `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${process.env.FIREBASE_API_KEY}`,
          { method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password: String(b.password || ""), returnSecureToken: true }) });
        if (!r.ok) return reply(400, { error: "bad_login" });
        const j = await r.json();
        return reply(200, await tokenFor(j.localId));
      }

      case "resetPw": { // set a new password after WhatsApp OTP
        const password = String(b.password || "");
        if (password.length < 8) return reply(400, { error: "weak_pw" });
        const u = await userByPhone(mobile);
        if (!u) return reply(400, { error: "no_user" });
        const upd = { password };
        if (!u.email) upd.email = SYNTH(mobile);
        await admin().auth().updateUser(u.uid, upd);
        return reply(200, await tokenFor(u.uid));
      }

      default:
        return reply(400, { error: "bad_action" });
    }
  } catch (e) {
    console.error(e);
    return reply(500, { error: "server" });
  }
};
