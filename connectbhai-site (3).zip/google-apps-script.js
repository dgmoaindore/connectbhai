// Paste this in Google Sheet > Extensions > Apps Script, then
// Deploy > New deployment > Web app > Execute as: Me, Who has access: Anyone.
// Copy the Web app URL into Netlify as SHEET_WEBHOOK.
function doPost(e) {
  var d = JSON.parse(e.postData.contents);
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Leads")
        || SpreadsheetApp.getActiveSpreadsheet().insertSheet("Leads");
  if (sh.getLastRow() === 0) {
    sh.appendRow(["Request ID","Time","Name","Mobile","Area","Pincode","Service","Type","Status"]);
  }
  sh.appendRow([d.requestId, d.time, d.name, "'" + d.mobile, d.area, "'" + d.pincode, d.service, d.type, d.status]);
  return ContentService.createTextOutput(JSON.stringify({ ok: true }))
    .setMimeType(ContentService.MimeType.JSON);
}
